defmodule Project3Test do
  use ExUnit.Case
  doctest Project3

  test "greets the world" do
    assert Project3.hello() == :world
  end
end
